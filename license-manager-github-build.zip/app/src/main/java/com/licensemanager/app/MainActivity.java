package com.licensemanager.app;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private static final String HOME = "https://licensemanager.ct.ws/user-dashboard.php";

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8,11,22));
        getWindow().setNavigationBarColor(Color.rgb(8,11,22));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(8,11,22));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false); s.setAllowContentAccess(false); s.setSupportZoom(false);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false); s.setLoadsImagesAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
                String u=r.getUrl().toString();
                return !(u.startsWith("https://licensemanager.ct.ws/") || u.startsWith("https://licensemanager.shop/"));
            }
        });
        setContentView(webView); webView.loadUrl(HOME);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true){
            @Override public void handleOnBackPressed(){ if(webView.canGoBack()) webView.goBack(); else finish(); }
        });
    }
    @Override protected void onResume(){ super.onResume(); CookieManager.getInstance().flush(); }
    @Override protected void onPause(){ CookieManager.getInstance().flush(); super.onPause(); }
}
