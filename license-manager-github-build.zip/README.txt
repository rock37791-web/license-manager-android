LICENSE MANAGER Android Wrapper

Website URL:
https://licensemanager.ct.ws/user-dashboard.php

This project does NOT modify the PHP website. It is a native Android WebView wrapper that opens the live website.

App name: LICENSE MANAGER
Application ID: com.licensemanager.app
Version: 1.0 (code 1)
Minimum Android: 6.0 (API 23)

Build with Android Studio:
1. Open this folder as an Android Studio project.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on Android.

The launcher icon uses the supplied LICENSE MANAGER PNG logo.
