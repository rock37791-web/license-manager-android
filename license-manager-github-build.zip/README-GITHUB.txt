LICENSE MANAGER - GitHub APK Build

1. Create a new GitHub repository (for example: license-manager-android).
2. Upload ALL files and folders from this project into the repository root.
3. Make sure .github/workflows/build-apk.yml is uploaded too.
4. Commit to the main branch.
5. Open the repository -> Actions -> Build LICENSE MANAGER APK.
6. Open the completed green workflow run.
7. Scroll to Artifacts and download LICENSE-MANAGER-APK.
8. Extract the downloaded ZIP and install the APK on Android.

The app loads https://licensemanager.ct.ws/user-dashboard.php and does not modify the PHP website.
